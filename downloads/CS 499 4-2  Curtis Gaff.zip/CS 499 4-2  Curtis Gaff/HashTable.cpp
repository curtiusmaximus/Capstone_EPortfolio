//============================================================================
// Name        : HashTable.cpp
// Author      : Curtis Gaff
// Version     : 2.0 (Enhanced Version)
// Description : Hash Table with separate chaining, improved hashing,
//               load factor tracking, rehashing, and sorted output.
//============================================================================

#include <algorithm>
#include <climits>
#include <iostream>
#include <string>
#include <time.h>
#include <vector>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

const unsigned int DEFAULT_SIZE = 179;
const double MAX_LOAD_FACTOR = 0.75; // threshold to trigger rehash

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;

    Bid() {
        amount = 0.0;
    }
};

//============================================================================
// Hash Table class definition
//============================================================================

/**
 * Hash table with separate chaining using a vector of bucket heads.
 * Enhancements:
 *  - String-based DJB2 hash for better distribution
 *  - Load factor tracking and automatic rehashing
 *  - Method to retrieve bids sorted by title
 */
class HashTable {

private:
    // Node used in the chains for each bucket
    struct Node {
        Bid bid;
        unsigned int key; // bucket index for this node
        Node* next;

        // default constructor
        Node() {
            key = UINT_MAX; // UINT_MAX means "unused bucket"
            next = nullptr;
        }

        // initialize with a bid
        Node(Bid aBid) : Node() {
            bid = aBid;
        }

        // initialize with a bid and a key
        Node(Bid aBid, unsigned int aKey) : Node(aBid) {
            key = aKey;
        }
    };

    // vector of buckets (each entry is the head node of a chain)
    vector<Node> nodes;

    unsigned int tableSize;
    size_t numElements; // number of bids currently stored

    // improved hash function using DJB2 on string key
    unsigned int hash(const string& key);

    // current load factor = numElements / tableSize
    double loadFactor() const;

    // rehash into a larger table
    void rehash(unsigned int newSize);

public:
    HashTable();
    HashTable(unsigned int size);
    virtual ~HashTable();

    void Insert(Bid bid);
    void PrintAll();
    void Remove(string bidId);
    Bid Search(string bidId);
    size_t Size();

    // Enhancement: get all bids sorted by title
    vector<Bid> GetBidsSortedByTitle();
};

/**
 * Default constructor
 */
HashTable::HashTable() {
    tableSize = DEFAULT_SIZE;
    numElements = 0;
    nodes.resize(tableSize);
}

/**
 * Constructor for specifying size of the table.
 */
HashTable::HashTable(unsigned int size) {
    tableSize = size;
    numElements = 0;
    nodes.resize(tableSize);
}

/**
 * Destructor
 *
 * Free any heap-allocated nodes in the chains.
 */
HashTable::~HashTable() {
    // iterate over each bucket
    for (unsigned int i = 0; i < tableSize; ++i) {
        Node* current = nodes[i].next;  // start with first chained node
        while (current != nullptr) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
        nodes[i].next = nullptr;
    }
}

/**
 * Improved hash function using the DJB2 algorithm on a string key.
 *
 * Complexity: O(n) where n = length of the key.
 * Returns a value in [0, tableSize - 1].
 */
unsigned int HashTable::hash(const string& key) {
    unsigned long hashValue = 5381;

    for (unsigned char c : key) {
        // hashValue * 33 + c
        hashValue = ((hashValue << 5) + hashValue) + c;
    }

    return static_cast<unsigned int>(hashValue % tableSize);
}

/**
 * Compute current load factor.
 */
double HashTable::loadFactor() const {
    if (tableSize == 0) {
        return 0.0;
    }
    return static_cast<double>(numElements) / static_cast<double>(tableSize);
}

/**
 * Rehash the table into a new table with the given size.
 *
 * Steps:
 *  - Collect all existing bids into a temporary vector
 *  - Clear and resize the bucket vector
 *  - Reinsert all bids using the current Insert logic
 */
void HashTable::rehash(unsigned int newSize) {
    if (newSize <= tableSize) {
        return; // ensure we always grow
    }

    // collect all existing bids
    vector<Bid> existingBids;
    existingBids.reserve(numElements);

    for (unsigned int i = 0; i < tableSize; ++i) {
        Node* head = &nodes[i];

        if (head->key == UINT_MAX) {
            continue;
        }

        // head node
        existingBids.push_back(head->bid);

        // chained nodes
        Node* current = head->next;
        while (current != nullptr) {
            existingBids.push_back(current->bid);
            Node* temp = current;
            current = current->next;
            delete temp;
        }
        head->next = nullptr;
    }

    // reset to new table
    nodes.clear();
    tableSize = newSize;
    nodes.resize(tableSize);
    numElements = 0;

    // reinsert all bids (Insert may trigger further rehashing if needed)
    for (const Bid& b : existingBids) {
        Insert(b);
    }
}

/**
 * Insert a bid into the hash table.
 *
 * @param bid The bid to insert
 */
void HashTable::Insert(Bid bid) {
    if (tableSize == 0) {
        // safety: avoid division by zero in hash
        tableSize = DEFAULT_SIZE;
        nodes.resize(tableSize);
    }

    unsigned int bucketIndex = hash(bid.bidId);
    Node* bucket = &nodes[bucketIndex];

    // if this bucket is empty (unused)
    if (bucket->key == UINT_MAX) {
        bucket->key = bucketIndex;
        bucket->bid = bid;
        bucket->next = nullptr;
    }
    else {
        // otherwise, walk to the end of the chain and append a new node
        Node* current = bucket;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = new Node(bid, bucketIndex);
    }

    ++numElements;

    // check load factor and rehash if necessary
    if (loadFactor() > MAX_LOAD_FACTOR) {
        unsigned int newSize = tableSize * 2 + 1; // simple growth strategy
        rehash(newSize);
    }
}

/**
 * Print all bids in the hash table (unsorted).
 */
void HashTable::PrintAll() {
    for (unsigned int i = 0; i < tableSize; ++i) {
        Node* node = &nodes[i];

        // skip unused buckets
        if (node->key == UINT_MAX) {
            continue;
        }

        // print the head of the chain
        cout << node->bid.bidId << ": " << node->bid.title
            << " | " << node->bid.amount
            << " | " << node->bid.fund << endl;

        // print any chained nodes
        Node* current = node->next;
        while (current != nullptr) {
            cout << current->bid.bidId << ": " << current->bid.title
                << " | " << current->bid.amount
                << " | " << current->bid.fund << endl;
            current = current->next;
        }
    }
}

/**
 * Remove a bid from the table.
 *
 * @param bidId The bid id to remove
 */
void HashTable::Remove(string bidId) {
    if (tableSize == 0) {
        return;
    }

    unsigned int bucketIndex = hash(bidId);
    Node* bucket = &nodes[bucketIndex];

    // if bucket is unused, nothing to remove
    if (bucket->key == UINT_MAX) {
        return;
    }

    // case 1: the head node contains the bid
    if (bucket->bid.bidId == bidId) {
        if (bucket->next == nullptr) {
            // single node in bucket, mark as unused
            bucket->key = UINT_MAX;
            bucket->bid = Bid();
        }
        else {
            // copy data from next node into head and delete next
            Node* temp = bucket->next;
            bucket->bid = temp->bid;
            bucket->key = temp->key;
            bucket->next = temp->next;
            delete temp;
        }
        --numElements;
        return;
    }

    // case 2: bid is in the chain
    Node* prev = bucket;
    Node* current = bucket->next;

    while (current != nullptr) {
        if (current->bid.bidId == bidId) {
            prev->next = current->next;
            delete current;
            --numElements;
            return;
        }
        prev = current;
        current = current->next;
    }
}

/**
 * Search for the specified bidId.
 *
 * @param bidId The bid id to search for
 * @return The matching Bid, or an empty Bid if not found
 */
Bid HashTable::Search(string bidId) {
    Bid bid; // default (empty) bid to return if not found

    if (tableSize == 0) {
        return bid;
    }

    unsigned int bucketIndex = hash(bidId);
    Node* node = &nodes[bucketIndex];

    // unused bucket � nothing to search
    if (node->key == UINT_MAX) {
        return bid;
    }

    // check head of chain
    if (node->bid.bidId == bidId) {
        return node->bid;
    }

    // walk the chain
    Node* current = node->next;
    while (current != nullptr) {
        if (current->bid.bidId == bidId) {
            return current->bid;
        }
        current = current->next;
    }

    // not found
    return bid;
}

/**
 * Return number of bids currently stored in the table.
 */
size_t HashTable::Size() {
    return numElements;
}

/**
 * Enhancement: collect all bids into a vector and return them
 * sorted by title using std::sort.
 */
vector<Bid> HashTable::GetBidsSortedByTitle() {
    vector<Bid> bids;
    bids.reserve(numElements);

    for (unsigned int i = 0; i < tableSize; ++i) {
        Node* node = &nodes[i];

        if (node->key == UINT_MAX) {
            continue;
        }

        // add head
        bids.push_back(node->bid);

        // add chained nodes
        Node* current = node->next;
        while (current != nullptr) {
            bids.push_back(current->bid);
            current = current->next;
        }
    }

    sort(bids.begin(), bids.end(), [](const Bid& a, const Bid& b) {
        return a.title < b.title;
        });

    return bids;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
        << bid.fund << endl;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 */
void loadBids(string csvPath, HashTable* hashTable) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            // insert bid into the hash table
            hashTable->Insert(bid);
        }
    }
    catch (csv::Error& e) {
        cerr << e.what() << endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98223";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales.csv";
        bidKey = "98223";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a hash table to hold all the bids
    HashTable* bidTable = new HashTable();

    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  5. Display Bids Sorted by Title" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            // Initialize a timer variable before loading bids
            ticks = clock();

            // load the bids
            loadBids(csvPath, bidTable);

            // Calculate elapsed time and display result
            ticks = clock() - ticks;
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            bidTable->PrintAll();
            break;

        case 3:
            ticks = clock();

            bid = bidTable->Search(bidKey);

            ticks = clock() - ticks;

            if (!bid.bidId.empty()) {
                displayBid(bid);
            }
            else {
                cout << "Bid Id " << bidKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 4:
            bidTable->Remove(bidKey);
            break;

        case 5: {
            vector<Bid> sortedBids = bidTable->GetBidsSortedByTitle();
            for (const Bid& b : sortedBids) {
                displayBid(b);
            }
            break;
        }
        }
    }

    cout << "Good bye." << endl;

    delete bidTable;
    return 0;
}
