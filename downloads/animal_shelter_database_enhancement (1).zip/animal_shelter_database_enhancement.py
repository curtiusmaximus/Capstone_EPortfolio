# animal_shelter.py

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter(object):
    """
    CRUD operations for Animal collection in MongoDB.
    Enhancements:
    - Input validation for documents and queries
    - Safer update/delete behavior
    - More consistent error handling and messaging
    """

    # Minimal required fields for a valid animal document
    REQUIRED_FIELDS = {
        "animal_id",
        "animal_type",
        "breed",
        "age_upon_outcome",
        "outcome_type"
    }

    def __init__(self):
        """
        Initializes the MongoDB client and sets the database and collection.
        """
        USER = "aacuser"
        PASS = "SNHU1234"
        HOST = "nv-desktop-services.apporto.com"
        PORT = 34073
        DB = "AAC"
        COL = "animals"

        try:
            self.client = MongoClient(f"mongodb://{USER}:{PASS}@{HOST}:{PORT}")
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except PyMongoError as e:
            # Fail fast: this is a critical error
            raise Exception(f"Failed to connect to database: {e}")

    # ------------------------------------------------------------------
    # Internal helpers for validation
    # ------------------------------------------------------------------

    def _validate_document(self, data):
        """
        Validates a document before insertion.
        - Must be a non-empty dict
        - Must contain required fields with non-empty values
        """
        if not isinstance(data, dict) or not data:
            raise ValueError("Invalid data. Must be a non-empty dictionary.")

        # Ensure required fields are present and non-empty
        missing = []
        empty_required = []

        for field in self.REQUIRED_FIELDS:
            if field not in data:
                missing.append(field)
            else:
                value = data[field]
                if value is None or (isinstance(value, str) and not value.strip()):
                    empty_required.append(field)

        if missing:
            raise ValueError(
                f"Document missing required fields: {', '.join(sorted(missing))}"
            )

        if empty_required:
            raise ValueError(
                "Required fields must not be empty or whitespace: "
                f"{', '.join(sorted(empty_required))}"
            )

        # Optionally normalize string fields (strip whitespace)
        cleaned = {}
        for key, value in data.items():
            if isinstance(value, str):
                cleaned[key] = value.strip()
            else:
                cleaned[key] = value

        return cleaned

    def _validate_query(self, query, allow_empty=False):
        """
        Validates a query dictionary.

        - Must be a dict
        - Empty dict allowed only when allow_empty=True (e.g., read all)
        """
        if not isinstance(query, dict):
            raise ValueError("Invalid query. Must be a dictionary.")

        if not query and not allow_empty:
            raise ValueError(
                "Invalid query. Empty query is not allowed for this operation."
            )

        return query

    # ------------------------------------------------------------------
    # Public CRUD interface
    # ------------------------------------------------------------------

    def create(self, data):
        """
        Inserts a new document into the collection.
        Returns True if successful, else False.

        Enhancements:
        - Validates required fields and basic structure before insert.
        - Normalizes string values (strips whitespace).
        """
        try:
            cleaned = self._validate_document(data)
        except ValueError as ve:
            # Validation errors are programmer/data errors, not DB errors
            print(f"Validation error in create(): {ve}")
            return False

        try:
            result = self.collection.insert_one(cleaned)
            return result.acknowledged
        except PyMongoError as e:
            print(f"Insert failed: {e}")
            return False

    def read(self, query):
        """
        Finds documents in the collection that match the query.
        Returns a list of matching documents or an empty list if none found.

        Enhancements:
        - Validates that query is a dict.
        - Allows empty dict to support 'read all' behavior.
        """
        try:
            validated_query = self._validate_query(query, allow_empty=True)
        except ValueError as ve:
            print(f"Validation error in read(): {ve}")
            return []

        try:
            cursor = self.collection.find(validated_query)
            return list(cursor)
        except PyMongoError as e:
            print(f"Read failed: {e}")
            return []

    def update(self, query, new_values, update_many=False):
        """
        Updates one or more documents in the collection.
        Returns number of documents modified.

        Enhancements:
        - Validates query is a non-empty dict (prevents updating everything by accident).
        - Validates new_values is a non-empty dict.
        - Uses more specific exception handling.
        """
        try:
            validated_query = self._validate_query(query, allow_empty=False)
        except ValueError as ve:
            print(f"Validation error in update(): {ve}")
            return 0

        if not isinstance(new_values, dict) or not new_values:
            print("Validation error in update(): new_values must be a non-empty dict.")
            return 0

        try:
            if update_many:
                result = self.collection.update_many(validated_query, new_values)
            else:
                result = self.collection.update_one(validated_query, new_values)

            return result.modified_count

        except PyMongoError as e:
            print(f"An error occurred while updating: {e}")
            return 0

    def delete(self, query, delete_many=False):
        """
        Deletes one or more documents in the collection.
        Returns number of documents deleted.

        Enhancements:
        - Validates query is a non-empty dict (prevents deleting everything by accident).
        - Uses more specific exception handling.
        """
        try:
            validated_query = self._validate_query(query, allow_empty=False)
        except ValueError as ve:
            print(f"Validation error in delete(): {ve}")
            return 0

        try:
            if delete_many:
                result = self.collection.delete_many(validated_query)
            else:
                result = self.collection.delete_one(validated_query)

            return result.deleted_count

        except PyMongoError as e:
            print(f"An error occurred while deleting: {e}")
            return 0
