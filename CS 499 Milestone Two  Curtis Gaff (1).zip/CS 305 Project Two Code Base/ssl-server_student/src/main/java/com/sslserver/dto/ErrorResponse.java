package com.sslserver.dto;

import java.time.Instant;

public class ErrorResponse {

    private String error;
    private String path;
    private Instant timestamp = Instant.now();

    public ErrorResponse() {
        // default
    }

    public ErrorResponse(String error, String path) {
        this.error = error;
        this.path = path;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }
}
