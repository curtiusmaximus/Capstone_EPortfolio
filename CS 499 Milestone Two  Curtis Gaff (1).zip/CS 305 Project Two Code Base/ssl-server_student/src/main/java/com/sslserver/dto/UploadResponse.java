package com.sslserver.dto;

import java.time.Instant;

public class UploadResponse {

    private String originalFilename;
    private String sha256;
    private long sizeBytes;
    private String message;
    private Instant timestamp = Instant.now();

    public UploadResponse() {
        // default constructor
    }

    public UploadResponse(String originalFilename, String sha256, long sizeBytes, String message) {
        this.originalFilename = originalFilename;
        this.sha256 = sha256;
        this.sizeBytes = sizeBytes;
        this.message = message;
    }

    public String getOriginalFilename() {
        return originalFilename;
    }

    public void setOriginalFilename(String originalFilename) {
        this.originalFilename = originalFilename;
    }

    public String getSha256() {
        return sha256;
    }

    public void setSha256(String sha256) {
        this.sha256 = sha256;
    }

    public long getSizeBytes() {
        return sizeBytes;
    }

    public void setSizeBytes(long sizeBytes) {
        this.sizeBytes = sizeBytes;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }
}
