package com.sslserver.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class UploadRequest {

    @NotBlank(message = "expectedChecksum is required")
    @Pattern(
        regexp = "^[A-Fa-f0-9]{64}$",
        message = "expectedChecksum must be a 64-character hex string"
    )
    private String expectedChecksum;

    public String getExpectedChecksum() {
        return expectedChecksum;
    }

    public void setExpectedChecksum(String expectedChecksum) {
        this.expectedChecksum = expectedChecksum;
    }
}
