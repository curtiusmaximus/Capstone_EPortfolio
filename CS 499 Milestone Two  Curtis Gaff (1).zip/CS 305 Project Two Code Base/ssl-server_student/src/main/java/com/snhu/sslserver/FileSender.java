package com.snhu.sslserver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;

public class FileSender {
    public static void main(String[] args) {
        try {
            // Select  file to send
            File file = new File("testfile.txt");  // Ensure testfile.txt exists in the root folder

            // Generate SHA-256 checksum for file
            String checksum = ChecksumUtil.generateSHA256Checksum(file);
            System.out.println("Generated Checksum: " + checksum);

            // Send file and checksum to server
            sendFile(file, checksum);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void sendFile(File file, String checksum) throws IOException {
        byte[] fileBytes = Files.readAllBytes(Paths.get(file.getAbsolutePath()));

        // Server API URL
        URL url = new URL("http://localhost:8080/api/files/upload?expectedChecksum=" + checksum);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoOutput(true);
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/octet-stream");

        // Send file data
        try (OutputStream os = connection.getOutputStream()) {
            os.write(fileBytes);
        }

        // Print server response
        int responseCode = connection.getResponseCode();
        System.out.println("Response Code: " + responseCode);
    }
}
