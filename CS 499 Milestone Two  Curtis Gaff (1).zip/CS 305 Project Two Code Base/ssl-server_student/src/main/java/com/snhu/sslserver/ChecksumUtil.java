package com.snhu.sslserver;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;

public class ChecksumUtil {

    /* New method to compute SHA-256 from any InputStream using streaming.*/
    public static String sha256Hex(InputStream in) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (DigestInputStream dis = new DigestInputStream(in, digest)) {
            byte[] buffer = new byte[8192];
            while (dis.read(buffer) != -1) {
                // reading updates the digest
            }
        }
        byte[] hash = digest.digest();
        StringBuilder sb = new StringBuilder(hash.length * 2);
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    /* Backwards-compatible method that now delegates to the streaming method.*/
    public static String generateSHA256Checksum(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            return sha256Hex(fis);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
