package com.snhu.sslserver;

import com.sslserver.dto.UploadResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/files")
@Validated
public class FileUploadController {

    private final List<String> allowedTypes;

    public FileUploadController(
            @Value("${app.allowedContentTypes:}") String allowedContentTypes) {

        if (allowedContentTypes == null || allowedContentTypes.trim().isEmpty()) {
            this.allowedTypes = List.of();
        } else {
            this.allowedTypes = Arrays.asList(allowedContentTypes.split("\\s*,\\s*"));
        }
    }

    @PostMapping("/upload")
    public ResponseEntity<UploadResponse> uploadFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam("expectedChecksum")
            @NotBlank(message = "expectedChecksum is required")
            @Pattern(regexp = "^[A-Fa-f0-9]{64}$",
                     message = "expectedChecksum must be a 64-character hex string")
                    String expectedChecksum) {

        if (file == null || file.isEmpty()) {
            UploadResponse resp = new UploadResponse(
                    null,
                    null,
                    0,
                    "No file provided"
            );
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp);
        }

        // Content-type allow list
        if (!allowedTypes.isEmpty()) {
            String contentType = file.getContentType();
            if (contentType == null || !allowedTypes.contains(contentType)) {
                UploadResponse resp = new UploadResponse(
                        file.getOriginalFilename(),
                        null,
                        file.getSize(),
                        "Unsupported content type: " + contentType
                );
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp);
            }
        }

        try {
            String actualChecksum = ChecksumUtil.sha256Hex(file.getInputStream());
            boolean matches = actualChecksum != null
                    && actualChecksum.equalsIgnoreCase(expectedChecksum);

            String message = matches
                    ? "File uploaded successfully. Checksum verified."
                    : "File uploaded, but checksum mismatch.";

            UploadResponse resp = new UploadResponse(
                    file.getOriginalFilename(),
                    actualChecksum,
                    file.getSize(),
                    message
            );

            return ResponseEntity.ok(resp);

        } catch (Exception e) {
            UploadResponse resp = new UploadResponse(
                    file.getOriginalFilename(),
                    null,
                    file.getSize(),
                    "Error processing file."
            );
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }
}
