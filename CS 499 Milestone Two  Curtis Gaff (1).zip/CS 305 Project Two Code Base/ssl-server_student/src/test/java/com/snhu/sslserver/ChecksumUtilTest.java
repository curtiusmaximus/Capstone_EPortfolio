package com.snhu.sslserver;

import org.junit.jupiter.api.Test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ChecksumUtilTest {

    @Test
    void generateSHA256Checksum_returnsExpectedHashForKnownContent() throws Exception {
        // Arrange: create a temporary file with known content
        String content = "hello";
        Path tempFile = Files.createTempFile("checksum-test-", ".txt");
        Files.write(tempFile, content.getBytes());

        // This is the known SHA-256 for the string "hello"
        String expectedSha256 = "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824";

        // Act
        String actual = ChecksumUtil.generateSHA256Checksum(tempFile.toFile());

        // Assert
        assertNotNull(actual, "Checksum should not be null");
        assertEquals(expectedSha256, actual, "Checksum should match the expected SHA-256 value");

        // Cleanup
        Files.deleteIfExists(tempFile);
    }
}
