package com.snhu.sslserver;

import java.io.File;

public class ChecksumTest {
	
    public static void main(String[] args) {
        // Path to test file
        File file = new File("testfile.txt");

        // Generate SHA-256 checksum
        String checksum = ChecksumUtil.generateSHA256Checksum(file);

        // Print output
        if (checksum != null) {
            System.out.println("Generated SHA-256 Checksum: " + checksum);
        } else {
            System.out.println("Checksum generation failed.");
        }
    }

}
