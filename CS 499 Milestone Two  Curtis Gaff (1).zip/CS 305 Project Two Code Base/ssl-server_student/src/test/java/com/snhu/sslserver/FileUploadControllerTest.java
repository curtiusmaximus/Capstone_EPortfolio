package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class FileUploadControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void uploadFile_withValidChecksum_returnsVerifiedMessage() throws Exception {
        // Arrange: file content and its known SHA-256
        String content = "hello";
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "hello.txt",
                "text/plain",
                content.getBytes()
        );

        String expectedSha256 = "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824";

        // Act + Assert
        mockMvc.perform(multipart("/api/files/upload")
                        .file(file)
                        .param("expectedChecksum", expectedSha256)
                        .contentType(MediaType.MULTIPART_FORM_DATA))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message",
                        containsString("Checksum verified")));
    }

    @Test
    void uploadFile_withInvalidChecksumFormat_returnsBadRequest() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "hello.txt",
                "text/plain",
                "hello".getBytes()
        );

        // invalid (too short) checksum triggers validation
        String badChecksum = "abc123";

        mockMvc.perform(multipart("/api/files/upload")
                        .file(file)
                        .param("expectedChecksum", badChecksum)
                        .contentType(MediaType.MULTIPART_FORM_DATA))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error",
                        containsString("expectedChecksum must be a 64-character hex string")));
    }
}
